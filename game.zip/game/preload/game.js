var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/// <reference path="../phaser.d.ts"/>
var GameJam;
(function (GameJam) {
    var Preload;
    (function (Preload_1) {
        var Preload = (function (_super) {
            __extends(Preload, _super);
            function Preload() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            Preload.prototype.preload = function () {
                // Images
                this.game.load.image('tiles', 'assets/maps/tiles/tiles.png');
                this.game.load.image('darkness', 'assets/maps/tiles/darkness.png');
                this.game.load.image('background', 'assets/misc/background.png');
                this.game.load.image('speechbubble', 'assets/misc/speechbubble.png');
                // Spritesheets
                this.game.load.spritesheet('player', 'assets/spritesheets/player.png', 64, 64);
                this.game.load.spritesheet('victim', 'assets/spritesheets/victim.png', 64, 64);
                this.game.load.spritesheet('container', 'assets/spritesheets/container.png', 100, 100);
                // Maps
                this.game.load.tilemap('map_test', 'assets/maps/map_test.json', null, Phaser.Tilemap.TILED_JSON);
                this.game.load.tilemap('map_container_test', 'assets/maps/map_container_test.json', null, Phaser.Tilemap.TILED_JSON);
                this.game.load.tilemap('map_sticky_test', 'assets/maps/map_sticky_test.json', null, Phaser.Tilemap.TILED_JSON);
                // Sound
                //this.game.load.audio('music', 'assets/music.mp3');
                //this.game.load.audio('laser-snd', 'assets/laser.mp3');
            };
            Preload.prototype.create = function () {
                // Finished loading.
                this.game.state.start("level", true, false, 0);
            };
            return Preload;
        }(Phaser.State));
        Preload_1.Preload = Preload;
    })(Preload = GameJam.Preload || (GameJam.Preload = {}));
})(GameJam || (GameJam = {}));
/// <reference path="../phaser.d.ts"/>
var GameJam;
(function (GameJam) {
    var Level;
    (function (Level_1) {
        var LEVEL_MAP_LIST = ['map_sticky_test'];
        var NUMBER_OF_TRIES_MAP_LIST = [50];
        var PLAYER_VELOCITY = 300;
        var VICTIM_VELOCITY = 150;
        var TILE_WIDTH = 100;
        var TILE_HEIGHT = TILE_WIDTH;
        var TILE_INDEX_START_SOLID = 1;
        var TILE_INDEX_END_SOLID = 18;
        var TILE_INDEX_START_DEADLY = 23;
        var TILE_INDEX_END_DEADLY = 40;
        var TILE_INDEX_DARKNESS = 51;
        var ESCAPE_DISTANCE = 250;
        var ELevelState;
        (function (ELevelState) {
            ELevelState[ELevelState["FLYING"] = 0] = "FLYING";
            ELevelState[ELevelState["STICKING"] = 1] = "STICKING";
            ELevelState[ELevelState["WON"] = 2] = "WON";
            ELevelState[ELevelState["LOST"] = 3] = "LOST";
        })(ELevelState || (ELevelState = {}));
        var EVictimType;
        (function (EVictimType) {
            EVictimType[EVictimType["HORIZONTAL"] = 0] = "HORIZONTAL";
            EVictimType[EVictimType["VERTICAL"] = 1] = "VERTICAL";
        })(EVictimType || (EVictimType = {}));
        var Level = (function (_super) {
            __extends(Level, _super);
            function Level() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            Level.prototype.init = function (index) {
                this.mapIndex = index;
                this.mapName = LEVEL_MAP_LIST[index];
                this.numberOfTriesLeft = NUMBER_OF_TRIES_MAP_LIST[index];
                console.log("Initialized level " + this.mapName + ".");
            };
            Level.prototype.create = function () {
                this.map = this.game.add.tilemap(this.mapName);
                this.map.addTilesetImage('tiles');
                this.map.addTilesetImage('darkness');
                this.map.setCollisionBetween(TILE_INDEX_START_DEADLY, TILE_INDEX_END_DEADLY);
                this.map.setCollisionBetween(TILE_INDEX_START_SOLID, TILE_INDEX_END_SOLID);
                this.map.setCollisionBetween(TILE_INDEX_DARKNESS, TILE_INDEX_DARKNESS);
                // Create visible stuff.
                this.background = this.game.add.sprite(0, 0, 'background');
                this.background.fixedToCamera = true;
                this.layerSpaceship = this.map.createLayer('Spaceship');
                this.layerSpaceship.resizeWorld();
                this.game.physics.startSystem(Phaser.Physics.ARCADE);
                // Parse objects.
                this.victims = this.game.add.group();
                this.containers = this.game.add.group();
                this.speechBubble = this.game.add.sprite(0, 0, 'speechbubble');
                this.speechBubble.anchor.x = 1;
                this.speechBubble.anchor.y = 1;
                this.game.physics.arcade.enable(this.victims);
                for (var _i = 0, _a = this.map.objects['Objects']; _i < _a.length; _i++) {
                    var obj = _a[_i];
                    if (obj.name == "Player") {
                        this.createPlayer(obj.x, obj.y);
                    }
                    else if (obj.name == "VictimV") {
                        this.createVictim(obj.x, obj.y, EVictimType.VERTICAL);
                    }
                    else if (obj.name == "VictimH") {
                        this.createVictim(obj.x, obj.y, EVictimType.HORIZONTAL);
                    }
                    else if (obj.name == "Container") {
                        this.createContainer(obj.x, obj.y);
                    }
                }
                if (this.player == null) {
                    console.log("Error: Could not find object with type 'Player' in 'Objects'");
                }
                this.layerDarkness = this.map.createLayer('Darkness');
                this.layerDarkness.resizeWorld();
                // Init other stuff.
                this.shouldDie = false;
                this.playerInDarkness = false;
                this.flightLine = new Phaser.Line();
                this.numberOfCaughtEnemies = 0;
                this.textStyle = { font: "bold 32px Arial", fill: "#ff0000", boundsAlignH: "center", boundsAlignV: "middle" };
                this.numberOfTriesLeftText = this.game.add.text(0, 0, "", this.textStyle);
                this.numberOfTriesLeftText.fixedToCamera = true;
                this.updateNumberOfTriesLeftText();
                // Add event handlers.
                this.game.input.onDown.add(this.onClickDown, this);
                this.retryKey = this.game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
                this.retryKey.onDown.add(this.retry, this);
                //this.music = this.game.add.sound('music', 1, true);
                //this.music.play();
            };
            Level.prototype.createPlayer = function (x, y) {
                console.log("Creating player.");
                this.player = this.game.add.sprite(x + TILE_WIDTH / 2, y + TILE_HEIGHT / 2, 'player');
                this.player.anchor.x = 0.5;
                this.player.anchor.y = 0.5;
                this.player.animations.add('fly', [0, 1, 2, 3, 4, 5, 6, 7], 10, true);
                this.player.animations.add('stick', [8], 1, true);
                this.player.animations.add('bounce', [9], 1, true);
                this.player.animations.add('grilled', [10, 15], 10, true);
                this.player.animations.play('fly');
                this.game.physics.arcade.enable(this.player);
                this.player.body.velocity.x = -PLAYER_VELOCITY;
                this.player.body.velocity.y = 0;
                this.player.body.bounce.set(1);
                this.levelState = ELevelState.FLYING;
                this.game.camera.follow(this.player, Phaser.Camera.FOLLOW_LOCKON, 0.1, 0.1);
            };
            Level.prototype.createVictim = function (x, y, type) {
                console.log("Creating victim of type " + EVictimType[type] + ".");
                var victim = this.victims.create(x + TILE_WIDTH / 2, y + TILE_HEIGHT / 2, 'victim');
                victim.anchor.x = 0.5;
                victim.anchor.y = 0.5;
                victim.animations.add('fly', [0], 1, true);
                victim.animations.add('escape', [0, 1, 2, 3, 4, 5, 6, 7, 8], 10, true);
                victim.animations.play('fly');
                this.game.physics.arcade.enable(victim);
                victim.body.bounce.set(1);
                if (type == EVictimType.HORIZONTAL) {
                    victim.rotation = Math.PI / 2;
                    victim.body.velocity.x = VICTIM_VELOCITY;
                }
                else {
                    victim.rotation = Math.PI;
                    victim.body.velocity.y = VICTIM_VELOCITY;
                }
            };
            Level.prototype.createContainer = function (x, y) {
                console.log("Creating container.");
                var container = this.containers.create(x + TILE_WIDTH / 2, y + TILE_HEIGHT / 2, 'container');
                container.anchor.x = 0.5;
                container.anchor.y = 0.5;
                container.animations.add('still', [0], 1, false);
                container.animations.add('fight', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0], 10, false);
                container.animations.play('still');
                this.game.physics.arcade.enable(container);
            };
            Level.prototype.onClickDown = function (pointer) {
                if (this.levelState == ELevelState.STICKING) {
                    this.game.physics.arcade.moveToPointer(this.player, PLAYER_VELOCITY, pointer);
                    this.player.rotation = this.game.physics.arcade.angleToPointer(this.player, pointer) + (Math.PI / 2);
                    this.transitionToState(ELevelState.FLYING);
                }
            };
            Level.prototype.retry = function () {
                this.game.state.start("level", true, false, this.mapIndex);
            };
            Level.prototype.update = function () {
                var _this = this;
                if (this.levelState == ELevelState.STICKING) {
                    this.player.rotation = this.stickyRotation;
                }
                if (this.levelState == ELevelState.FLYING) {
                    this.updateVictimAnimations();
                }
                else {
                    this.resetVictimAnimations();
                }
                if (this.levelState != ELevelState.WON && this.levelState != ELevelState.LOST) {
                    this.shouldDie = false;
                    this.game.physics.arcade.overlap(this.player, this.layerSpaceship, function (p, tile) { if (_this.isTileDeadly(tile)) {
                        _this.shouldDie = true;
                    } }, null, this);
                    if (this.shouldDie) {
                        // Get grilled.
                        this.player.animations.play('grilled');
                        this.transitionToState(ELevelState.LOST);
                    }
                    else {
                        this.game.physics.arcade.collide(this.player, this.layerSpaceship, this.onPlayerCollidesWithSpaceShip, null, this);
                    }
                }
                this.game.physics.arcade.collide(this.victims, this.layerSpaceship, this.onVictimCollidesWithSpaceShip, null, this);
                if (this.levelState != ELevelState.WON && this.levelState != ELevelState.LOST) {
                    this.game.physics.arcade.overlap(this.player, this.victims, this.onPlayerOverlapsWithVictim, null, this);
                }
                if (this.levelState != ELevelState.WON && this.levelState != ELevelState.LOST) {
                    this.game.physics.arcade.overlap(this.player, this.containers, this.onPlayerOverlapsWithContainer, null, this);
                }
                if (this.levelState == ELevelState.STICKING) {
                    // Update flight line.
                    this.flightLine.start = this.player.position;
                    this.flightLine.end.x = this.game.input.activePointer.position.x + this.game.camera.view.x;
                    this.flightLine.end.y = this.game.input.activePointer.position.y + this.game.camera.view.y;
                }
            };
            Level.prototype.resetVictimAnimations = function () {
                var _this = this;
                this.victims.forEachAlive(function (v) {
                    v.animations.play('fly');
                    _this.faceVictimToItsDirection(v);
                }, this);
            };
            Level.prototype.updateVictimAnimations = function () {
                var _this = this;
                this.victims.forEachAlive(function (v) {
                    var distance = _this.player.position.distance(v.position);
                    if (distance < ESCAPE_DISTANCE) {
                        v.animations.play('escape');
                        v.scale.x = 1;
                        v.scale.y = -1;
                        v.rotation = (Math.PI / 2) + _this.game.physics.arcade.angleBetween(v, _this.player);
                    }
                    else {
                        v.animations.play('fly');
                        _this.faceVictimToItsDirection(v);
                    }
                }, this);
            };
            Level.prototype.faceVictimToItsDirection = function (v) {
                if (Math.abs(v.body.velocity.x) > 0.1) {
                    // Horizontal
                    v.rotation = Math.PI / 2;
                    if (v.body.velocity.x > 0) {
                        v.scale.y = 1;
                    }
                    else {
                        v.scale.y = -1;
                    }
                }
                else {
                    // Vertical
                    v.rotation = Math.PI;
                    if (v.body.velocity.y > 0) {
                        v.scale.y = 1;
                    }
                    else {
                        v.scale.y = -1;
                    }
                }
            };
            Level.prototype.onPlayerCollidesWithSpaceShip = function (player, spaceShipTile) {
                console.log("Collision detected of player with spaceship tile of index " + spaceShipTile.index + ".");
                var playerInDarkness = this.checkInDarkness();
                console.log("In Darkness : " + playerInDarkness);
                if (playerInDarkness) {
                    // Stick to wall.
                    if (this.numberOfTriesLeft > 0) {
                        // Rotate sprite to head away from the tile.
                        var diff = Phaser.Point.subtract(new Phaser.Point(spaceShipTile.worldX + TILE_WIDTH / 2, spaceShipTile.worldY + TILE_HEIGHT / 2), this.player.position);
                        this.player.body.angularVelocity = 0;
                        if (Math.abs(diff.x) > Math.abs(diff.y)) {
                            if (diff.x > 0) {
                                // From right
                                this.stickyRotation = -Math.PI / 2;
                            }
                            else {
                                // From left
                                this.stickyRotation = Math.PI / 2;
                            }
                        }
                        else {
                            if (diff.y > 0) {
                                // From top
                                this.stickyRotation = 0;
                            }
                            else {
                                // From bottom
                                this.stickyRotation = Math.PI;
                            }
                        }
                        this.transitionToState(ELevelState.STICKING);
                    }
                    else {
                        this.transitionToState(ELevelState.LOST);
                    }
                }
                else {
                    // Bounce from wall.
                    this.player.body.angularVelocity = -500;
                    this.player.animations.play('bounce');
                }
            };
            Level.prototype.checkInDarkness = function () {
                var _this = this;
                this.playerInDarkness = false;
                this.game.physics.arcade.overlap(this.player, this.layerDarkness, function (p, darknessTile) {
                    if (darknessTile.index != TILE_INDEX_DARKNESS) {
                        return;
                    }
                    // At least 50 % must intersect to be in darkness.
                    if (Phaser.Rectangle.containsPoint(new Phaser.Rectangle(darknessTile.worldX - 10, darknessTile.worldY - 10, TILE_WIDTH + 20, TILE_HEIGHT + 20), _this.player.position)) {
                        _this.playerInDarkness = true;
                    }
                    else {
                        console.log('nope: ');
                    }
                }, null, this);
                return this.playerInDarkness;
            };
            Level.prototype.isTileDeadly = function (spaceShipTile) {
                return TILE_INDEX_START_DEADLY <= spaceShipTile.index && spaceShipTile.index <= TILE_INDEX_END_DEADLY;
            };
            Level.prototype.onVictimCollidesWithSpaceShip = function (victim, spaceShipTile) {
            };
            Level.prototype.onPlayerOverlapsWithVictim = function (player, victim) {
                if (this.levelState == ELevelState.FLYING) {
                    victim.alive = false;
                    this.numberOfCaughtEnemies++;
                }
            };
            Level.prototype.onPlayerOverlapsWithContainer = function (player, container) {
                if (this.levelState == ELevelState.FLYING && this.victims.total == 0) {
                    // Caught all victims.
                    container.animations.play('fight');
                    this.speechBubble.x = container.worldX;
                    this.speechBubble.y = container.worldY;
                    this.game.time.events.add(200, function () {
                    }, this);
                    this.speechBubble.alpha = 0;
                    var fadeIn = this.game.add.tween(this.speechBubble).to({ alpha: 1 }, 300, "Linear", true, 300, 0, false);
                    var fadeOut = this.game.add.tween(this.speechBubble).to({ alpha: 0 }, 300, "Linear", false, 1000, 0, false);
                    fadeIn.chain(fadeOut);
                    this.transitionToState(ELevelState.WON);
                }
            };
            Level.prototype.transitionToState = function (next) {
                if (this.levelState == ELevelState.WON || this.levelState == ELevelState.LOST) {
                    // These are final states.
                    return;
                }
                if (next == this.levelState) {
                    return;
                }
                console.log("Transitioning from level state " + ELevelState[this.levelState] + " to level state " + ELevelState[next] + ".");
                if (next == ELevelState.STICKING) {
                    this.player.body.velocity.x = 0;
                    this.player.body.velocity.y = 0;
                    this.player.body.angularVelocity = 0;
                    this.player.animations.play('stick');
                }
                if (next == ELevelState.FLYING) {
                    this.numberOfTriesLeft--;
                    this.updateNumberOfTriesLeftText();
                    this.player.animations.play('fly');
                }
                if (next == ELevelState.WON) {
                    this.player.exists = false;
                    this.game.time.events.add(2000, this.switchToNextLevel, this);
                }
                if (next == ELevelState.LOST) {
                    this.player.body.velocity.x = 0;
                    this.player.body.velocity.y = 0;
                    this.player.body.angularVelocity = 0;
                    this.game.time.events.add(2000, this.retry, this);
                }
                this.levelState = next;
            };
            Level.prototype.updateNumberOfTriesLeftText = function () {
                this.numberOfTriesLeftText.text = "Jumps left: " + this.numberOfTriesLeft;
            };
            Level.prototype.switchToNextLevel = function () {
                var nextLevelIndex = (this.mapIndex + 1) % LEVEL_MAP_LIST.length;
                this.game.state.start("level", true, false, nextLevelIndex);
            };
            Level.prototype.render = function () {
                if (this.levelState == ELevelState.STICKING) {
                    this.game.debug.geom(this.flightLine);
                }
                //this.game.debug.body(this.player);
                //this.game.debug.body(this.layerSpaceship);
            };
            return Level;
        }(Phaser.State));
        Level_1.Level = Level;
    })(Level = GameJam.Level || (GameJam.Level = {}));
})(GameJam || (GameJam = {}));
/// <reference path="phaser.d.ts"/>
/// <reference path="preload/preload.ts"/>
/// <reference path="level/level.ts"/>
var GameJam;
(function (GameJam) {
    var MyGame = (function (_super) {
        __extends(MyGame, _super);
        function MyGame() {
            var _this = _super.call(this, 1200, 800, Phaser.CANVAS, 'content', undefined, undefined, false) || this;
            _this.state.add("preload", GameJam.Preload.Preload);
            _this.state.add("level", GameJam.Level.Level);
            _this.state.start("preload");
            return _this;
        }
        return MyGame;
    }(Phaser.Game));
    GameJam.MyGame = MyGame;
})(GameJam || (GameJam = {}));
window.onload = function () {
    var game = new GameJam.MyGame();
};
